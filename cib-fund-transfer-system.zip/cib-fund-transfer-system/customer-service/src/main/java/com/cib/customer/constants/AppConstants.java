package com.cib.customer.constants;

public final class AppConstants {

    private AppConstants() {
    }

    public static final String DEFAULT_PAGE_NUMBER = "0";
    public static final String DEFAULT_PAGE_SIZE = "10";
    public static final String DEFAULT_SORT_BY = "createdDate";
    public static final String DEFAULT_SORT_DIRECTION = "DESC";

    public static final String CUSTOMER_NOT_FOUND = "Corporate customer not found with id: %s";
    public static final String USER_NOT_FOUND = "Corporate user not found with id: %s";
    public static final String CIF_ALREADY_EXISTS = "Customer with CIF %s already exists";
    public static final String EMAIL_ALREADY_EXISTS = "User with email %s already exists";
}
