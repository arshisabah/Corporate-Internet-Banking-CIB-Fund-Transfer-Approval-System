package com.cib.approval.service.impl;

import com.cib.approval.client.FundTransferServiceClient;
import com.cib.approval.constants.AppConstants;
import com.cib.approval.dto.*;
import com.cib.approval.entity.ApprovalHistory;
import com.cib.approval.entity.ApprovalRequest;
import com.cib.approval.enums.ApprovalAction;
import com.cib.approval.enums.ApprovalStatus;
import com.cib.approval.exception.BusinessException;
import com.cib.approval.exception.ResourceNotFoundException;
import com.cib.approval.mapper.ApprovalMapper;
import com.cib.approval.repository.ApprovalHistoryRepository;
import com.cib.approval.repository.ApprovalRequestRepository;
import com.cib.approval.service.ApprovalService;
import com.cib.approval.specification.ApprovalSpecification;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApprovalServiceImpl implements ApprovalService {

    /**
     * Simple configurable approval-workflow rule: transactions above this threshold
     * require two levels of approval (maker-checker-approver), otherwise a single approval suffices.
     */
    private static final BigDecimal DUAL_APPROVAL_THRESHOLD = new BigDecimal("500000");

    private final ApprovalRequestRepository approvalRequestRepository;
    private final ApprovalHistoryRepository approvalHistoryRepository;
    private final ApprovalMapper approvalMapper;
    private final FundTransferServiceClient fundTransferServiceClient;

    @Override
    @Transactional
    public ApprovalSubmissionResponseDto submitForApproval(ApprovalSubmissionRequestDto requestDto) {
        ApprovalRequest approvalRequest = approvalMapper.toEntity(requestDto);
        approvalRequest.setStatus(ApprovalStatus.PENDING);
        approvalRequest.setCurrentLevel(1);
        approvalRequest.setRequiredLevels(resolveRequiredLevels(requestDto.getAmount()));

        ApprovalRequest saved = approvalRequestRepository.save(approvalRequest);
        recordHistory(saved, ApprovalAction.SUBMITTED, requestDto.getSubmittedBy(), "Submitted for approval");

        log.info("Approval request {} created for transaction {}", saved.getApprovalId(), saved.getTransactionId());

        return ApprovalSubmissionResponseDto.builder()
                .approvalId(saved.getApprovalId())
                .transactionId(saved.getTransactionId())
                .status(saved.getStatus().name())
                .build();
    }

    @Override
    public ApprovalResponseDto getApprovalById(Long approvalId) {
        return approvalMapper.toResponseDto(fetchApproval(approvalId));
    }

    @Override
    public PageResponse<ApprovalResponseDto> getPendingApprovals(Long customerId, ApprovalStatus status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(AppConstants.DEFAULT_SORT_BY).descending());
        Page<ApprovalRequest> result = approvalRequestRepository.findAll(
                ApprovalSpecification.filterBy(customerId, status), pageable);
        return PageResponse.from(result.map(approvalMapper::toResponseDto));
    }

    @Override
    @Transactional
    public ApprovalResponseDto approve(Long approvalId, ApprovalDecisionRequestDto decisionDto) {
        ApprovalRequest approvalRequest = fetchPendingApproval(approvalId);

        int nextLevel = approvalRequest.getCurrentLevel() + 1;
        recordHistory(approvalRequest, ApprovalAction.APPROVE, decisionDto.getApproverId(), decisionDto.getRemarks());

        if (nextLevel > approvalRequest.getRequiredLevels()) {
            approvalRequest.setStatus(ApprovalStatus.APPROVED);
            approvalRequestRepository.save(approvalRequest);
            log.info("Approval request {} fully approved at level {}", approvalId, approvalRequest.getCurrentLevel());
            notifyFundTransferService(approvalRequest, "EXECUTED", "Transaction approved through workflow and executed");
        } else {
            approvalRequest.setCurrentLevel(nextLevel);
            approvalRequestRepository.save(approvalRequest);
            log.info("Approval request {} approved at level {}, awaiting level {}", approvalId,
                    nextLevel - 1, nextLevel);
        }

        return approvalMapper.toResponseDto(approvalRequest);
    }

    @Override
    @Transactional
    public ApprovalResponseDto reject(Long approvalId, ApprovalDecisionRequestDto decisionDto) {
        ApprovalRequest approvalRequest = fetchPendingApproval(approvalId);
        approvalRequest.setStatus(ApprovalStatus.REJECTED);
        approvalRequestRepository.save(approvalRequest);
        recordHistory(approvalRequest, ApprovalAction.REJECT, decisionDto.getApproverId(), decisionDto.getRemarks());

        log.info("Approval request {} rejected", approvalId);
        notifyFundTransferService(approvalRequest, "REJECTED", decisionDto.getRemarks());

        return approvalMapper.toResponseDto(approvalRequest);
    }

    @Override
    @Transactional
    public ApprovalResponseDto returnForModification(Long approvalId, ApprovalDecisionRequestDto decisionDto) {
        ApprovalRequest approvalRequest = fetchPendingApproval(approvalId);
        approvalRequest.setStatus(ApprovalStatus.RETURNED_FOR_MODIFICATION);
        approvalRequestRepository.save(approvalRequest);
        recordHistory(approvalRequest, ApprovalAction.RETURN, decisionDto.getApproverId(), decisionDto.getRemarks());

        log.info("Approval request {} returned for modification", approvalId);
        notifyFundTransferService(approvalRequest, "RETURNED_FOR_MODIFICATION", decisionDto.getRemarks());

        return approvalMapper.toResponseDto(approvalRequest);
    }

    @Override
    public List<ApprovalHistoryResponseDto> getApprovalHistory(Long approvalId) {
        fetchApproval(approvalId);
        return approvalHistoryRepository.findByApprovalRequest_ApprovalIdOrderByActionDateAsc(approvalId).stream()
                .map(approvalMapper::toHistoryResponseDto)
                .collect(Collectors.toList());
    }

    private void notifyFundTransferService(ApprovalRequest approvalRequest, String newStatus, String remarks) {
        try {
            TransactionStatusUpdateDto updateDto = TransactionStatusUpdateDto.builder()
                    .newStatus(newStatus)
                    .approvalReferenceId(approvalRequest.getApprovalId())
                    .changedBy("APPROVAL_SERVICE")
                    .remarks(remarks)
                    .build();
            fundTransferServiceClient.updateTransactionStatus(approvalRequest.getTransactionId(), updateDto);
        } catch (FeignException ex) {
            log.error("Failed to notify Fund Transfer Service for transaction {}", approvalRequest.getTransactionId(), ex);
            throw new BusinessException(AppConstants.TRANSACTION_STATUS_UPDATE_FAILED);
        }
    }

    private int resolveRequiredLevels(BigDecimal amount) {
        return amount.compareTo(DUAL_APPROVAL_THRESHOLD) > 0 ? 2 : 1;
    }

    private void recordHistory(ApprovalRequest approvalRequest, ApprovalAction action, Long approverId, String remarks) {
        ApprovalHistory history = ApprovalHistory.builder()
                .approvalRequest(approvalRequest)
                .action(action)
                .approverId(approverId)
                .remarks(remarks)
                .build();
        approvalHistoryRepository.save(history);
    }

    private ApprovalRequest fetchPendingApproval(Long approvalId) {
        ApprovalRequest approvalRequest = fetchApproval(approvalId);
        if (approvalRequest.getStatus() != ApprovalStatus.PENDING) {
            throw new BusinessException(String.format(AppConstants.APPROVAL_NOT_PENDING, approvalId, approvalRequest.getStatus()));
        }
        return approvalRequest;
    }

    private ApprovalRequest fetchApproval(Long approvalId) {
        return approvalRequestRepository.findById(approvalId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        String.format(AppConstants.APPROVAL_NOT_FOUND, approvalId)));
    }
}
