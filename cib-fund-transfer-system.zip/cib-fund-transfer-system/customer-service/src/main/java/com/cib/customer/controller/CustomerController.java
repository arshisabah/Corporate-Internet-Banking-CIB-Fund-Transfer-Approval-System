package com.cib.customer.controller;

import com.cib.customer.constants.AppConstants;
import com.cib.customer.dto.ApiResponse;
import com.cib.customer.dto.CustomerRequestDto;
import com.cib.customer.dto.CustomerResponseDto;
import com.cib.customer.dto.PageResponse;
import com.cib.customer.enums.CustomerStatus;
import com.cib.customer.service.CustomerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/customers")
@RequiredArgsConstructor
@Tag(name = "Corporate Customer", description = "APIs for managing corporate customers")
public class CustomerController {

    private final CustomerService customerService;

    @PostMapping
    @Operation(summary = "Create a new corporate customer")
    public ResponseEntity<ApiResponse<CustomerResponseDto>> createCustomer(
            @Valid @RequestBody CustomerRequestDto requestDto) {
        CustomerResponseDto response = customerService.createCustomer(requestDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Corporate customer created successfully", response));
    }

    @GetMapping("/{customerId}")
    @Operation(summary = "Get corporate customer by id")
    public ResponseEntity<ApiResponse<CustomerResponseDto>> getCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(ApiResponse.success(customerService.getCustomerById(customerId)));
    }

    @GetMapping
    @Operation(summary = "Search / list corporate customers with pagination")
    public ResponseEntity<ApiResponse<PageResponse<CustomerResponseDto>>> searchCustomers(
            @RequestParam(required = false) String customerName,
            @RequestParam(required = false) String cif,
            @RequestParam(required = false) CustomerStatus status,
            @RequestParam(defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
            @RequestParam(defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size,
            @RequestParam(defaultValue = AppConstants.DEFAULT_SORT_BY) String sortBy,
            @RequestParam(defaultValue = AppConstants.DEFAULT_SORT_DIRECTION) String sortDirection) {
        return ResponseEntity.ok(ApiResponse.success(
                customerService.searchCustomers(customerName, cif, status, page, size, sortBy, sortDirection)));
    }

    @PutMapping("/{customerId}")
    @Operation(summary = "Update an existing corporate customer")
    public ResponseEntity<ApiResponse<CustomerResponseDto>> updateCustomer(
            @PathVariable Long customerId, @Valid @RequestBody CustomerRequestDto requestDto) {
        return ResponseEntity.ok(ApiResponse.success("Corporate customer updated successfully",
                customerService.updateCustomer(customerId, requestDto)));
    }

    @DeleteMapping("/{customerId}")
    @Operation(summary = "Delete a corporate customer")
    public ResponseEntity<ApiResponse<Void>> deleteCustomer(@PathVariable Long customerId) {
        customerService.deleteCustomer(customerId);
        return ResponseEntity.ok(ApiResponse.success("Corporate customer deleted successfully", null));
    }
}
