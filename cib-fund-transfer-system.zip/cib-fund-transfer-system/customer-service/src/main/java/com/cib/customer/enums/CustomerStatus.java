package com.cib.customer.enums;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
