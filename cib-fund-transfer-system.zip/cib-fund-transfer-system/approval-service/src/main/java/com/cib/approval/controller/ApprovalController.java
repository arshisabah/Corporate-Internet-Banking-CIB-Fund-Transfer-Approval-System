package com.cib.approval.controller;

import com.cib.approval.constants.AppConstants;
import com.cib.approval.dto.*;
import com.cib.approval.enums.ApprovalStatus;
import com.cib.approval.service.ApprovalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/approvals")
@RequiredArgsConstructor
@Tag(name = "Approval Workflow", description = "APIs for the fund transfer approval workflow")
public class ApprovalController {

    private final ApprovalService approvalService;

    @PostMapping
    @Operation(summary = "Submit a transaction for approval (called internally by Fund Transfer Service)")
    public ResponseEntity<ApiResponse<ApprovalSubmissionResponseDto>> submitForApproval(
            @Valid @RequestBody ApprovalSubmissionRequestDto requestDto) {
        ApprovalSubmissionResponseDto response = approvalService.submitForApproval(requestDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Transaction submitted for approval", response));
    }

    @GetMapping("/{approvalId}")
    @Operation(summary = "Get an approval request by id")
    public ResponseEntity<ApiResponse<ApprovalResponseDto>> getApproval(@PathVariable Long approvalId) {
        return ResponseEntity.ok(ApiResponse.success(approvalService.getApprovalById(approvalId)));
    }

    @GetMapping
    @Operation(summary = "List approval requests (e.g. pending approvals) with pagination")
    public ResponseEntity<ApiResponse<PageResponse<ApprovalResponseDto>>> getApprovals(
            @RequestParam(required = false) Long customerId,
            @RequestParam(required = false) ApprovalStatus status,
            @RequestParam(defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
            @RequestParam(defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return ResponseEntity.ok(ApiResponse.success(approvalService.getPendingApprovals(customerId, status, page, size)));
    }

    @PostMapping("/{approvalId}/approve")
    @Operation(summary = "Approve a pending approval request")
    public ResponseEntity<ApiResponse<ApprovalResponseDto>> approve(
            @PathVariable Long approvalId, @Valid @RequestBody ApprovalDecisionRequestDto decisionDto) {
        return ResponseEntity.ok(ApiResponse.success("Approval decision recorded successfully",
                approvalService.approve(approvalId, decisionDto)));
    }

    @PostMapping("/{approvalId}/reject")
    @Operation(summary = "Reject a pending approval request")
    public ResponseEntity<ApiResponse<ApprovalResponseDto>> reject(
            @PathVariable Long approvalId, @Valid @RequestBody ApprovalDecisionRequestDto decisionDto) {
        return ResponseEntity.ok(ApiResponse.success("Transaction rejected",
                approvalService.reject(approvalId, decisionDto)));
    }

    @PostMapping("/{approvalId}/return")
    @Operation(summary = "Return a pending approval request for modification")
    public ResponseEntity<ApiResponse<ApprovalResponseDto>> returnForModification(
            @PathVariable Long approvalId, @Valid @RequestBody ApprovalDecisionRequestDto decisionDto) {
        return ResponseEntity.ok(ApiResponse.success("Transaction returned for modification",
                approvalService.returnForModification(approvalId, decisionDto)));
    }

    @GetMapping("/{approvalId}/history")
    @Operation(summary = "Get the complete approval history for an approval request")
    public ResponseEntity<ApiResponse<List<ApprovalHistoryResponseDto>>> getApprovalHistory(@PathVariable Long approvalId) {
        return ResponseEntity.ok(ApiResponse.success(approvalService.getApprovalHistory(approvalId)));
    }
}
