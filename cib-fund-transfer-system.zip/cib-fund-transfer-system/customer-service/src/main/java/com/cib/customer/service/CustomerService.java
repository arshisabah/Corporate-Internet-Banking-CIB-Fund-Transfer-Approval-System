package com.cib.customer.service;

import com.cib.customer.dto.CustomerRequestDto;
import com.cib.customer.dto.CustomerResponseDto;
import com.cib.customer.dto.PageResponse;
import com.cib.customer.enums.CustomerStatus;

public interface CustomerService {

    CustomerResponseDto createCustomer(CustomerRequestDto requestDto);

    CustomerResponseDto getCustomerById(Long customerId);

    PageResponse<CustomerResponseDto> searchCustomers(String customerName, String cif, CustomerStatus status,
                                                        int page, int size, String sortBy, String sortDirection);

    CustomerResponseDto updateCustomer(Long customerId, CustomerRequestDto requestDto);

    void deleteCustomer(Long customerId);
}
