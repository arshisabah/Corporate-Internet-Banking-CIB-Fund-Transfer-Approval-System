package com.cib.beneficiary.enums;

public enum BeneficiaryStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}
