package com.cib.fundtransfer.enums;

public enum TransactionStatus {
    INITIATED,
    PENDING_APPROVAL,
    APPROVED,
    REJECTED,
    RETURNED_FOR_MODIFICATION,
    EXECUTED,
    FAILED
}
