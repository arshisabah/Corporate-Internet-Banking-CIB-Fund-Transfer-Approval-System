package com.cib.approval.entity;

import com.cib.approval.enums.ApprovalStatus;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "approval_request")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApprovalRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "approval_id")
    private Long approvalId;

    @Column(name = "transaction_id", nullable = false)
    private Long transactionId;

    @Column(name = "customer_id", nullable = false)
    private Long customerId;

    @Column(name = "submitted_by", nullable = false)
    private Long submittedBy;

    @Column(name = "amount", nullable = false, precision = 18, scale = 2)
    private BigDecimal amount;

    @Column(name = "currency", nullable = false, length = 5)
    private String currency;

    @Column(name = "remarks", length = 300)
    private String remarks;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private ApprovalStatus status;

    @Column(name = "current_level", nullable = false)
    private Integer currentLevel;

    @Column(name = "required_levels", nullable = false)
    private Integer requiredLevels;

    @Builder.Default
    @OneToMany(mappedBy = "approvalRequest", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ApprovalHistory> history = new ArrayList<>();

    @Column(name = "submitted_date", updatable = false)
    private LocalDateTime submittedDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @PrePersist
    protected void onCreate() {
        this.submittedDate = LocalDateTime.now();
        this.updatedDate = LocalDateTime.now();
        if (this.status == null) {
            this.status = ApprovalStatus.PENDING;
        }
        if (this.currentLevel == null) {
            this.currentLevel = 1;
        }
        if (this.requiredLevels == null) {
            this.requiredLevels = 1;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedDate = LocalDateTime.now();
    }
}
