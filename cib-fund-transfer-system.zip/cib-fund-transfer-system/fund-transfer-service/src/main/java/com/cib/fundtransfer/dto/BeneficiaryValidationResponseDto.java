package com.cib.fundtransfer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryValidationResponseDto {

    private Long beneficiaryId;
    private boolean valid;
    private String beneficiaryName;
    private String accountNumber;
    private String message;
}
