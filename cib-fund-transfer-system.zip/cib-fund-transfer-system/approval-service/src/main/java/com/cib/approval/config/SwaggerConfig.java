package com.cib.approval.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI approvalServiceOpenAPI() {
        return new OpenAPI().info(new Info()
                .title("Approval Service API")
                .description("APIs for managing the fund transfer approval workflow: approve, reject, return and history")
                .version("v1.0.0"));
    }
}
