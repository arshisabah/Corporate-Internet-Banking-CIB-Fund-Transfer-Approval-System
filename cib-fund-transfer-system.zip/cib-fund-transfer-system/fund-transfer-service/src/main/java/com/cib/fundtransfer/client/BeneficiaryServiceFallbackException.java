package com.cib.fundtransfer.client;

public class BeneficiaryServiceFallbackException extends RuntimeException {
    public BeneficiaryServiceFallbackException(String message) {
        super(message);
    }
}
