package com.cib.approval.service;

import com.cib.approval.dto.*;
import com.cib.approval.enums.ApprovalStatus;

import java.util.List;

public interface ApprovalService {

    ApprovalSubmissionResponseDto submitForApproval(ApprovalSubmissionRequestDto requestDto);

    ApprovalResponseDto getApprovalById(Long approvalId);

    PageResponse<ApprovalResponseDto> getPendingApprovals(Long customerId, ApprovalStatus status, int page, int size);

    ApprovalResponseDto approve(Long approvalId, ApprovalDecisionRequestDto decisionDto);

    ApprovalResponseDto reject(Long approvalId, ApprovalDecisionRequestDto decisionDto);

    ApprovalResponseDto returnForModification(Long approvalId, ApprovalDecisionRequestDto decisionDto);

    List<ApprovalHistoryResponseDto> getApprovalHistory(Long approvalId);
}
