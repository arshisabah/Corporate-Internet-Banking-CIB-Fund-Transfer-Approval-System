package com.cib.fundtransfer.service;

import com.cib.fundtransfer.dto.*;
import com.cib.fundtransfer.enums.TransactionStatus;

import java.util.List;

public interface FundTransferService {

    TransactionResponseDto initiateTransfer(TransactionRequestDto requestDto);

    TransactionResponseDto getTransactionById(Long transactionId);

    PageResponse<TransactionResponseDto> getTransactionHistory(Long customerId, Long beneficiaryId,
                                                                 TransactionStatus status, int page, int size,
                                                                 String sortBy, String sortDirection);

    TransactionResponseDto modifyAndResubmit(Long transactionId, TransactionRequestDto requestDto);

    TransactionResponseDto updateTransactionStatus(Long transactionId, TransactionStatusUpdateDto updateDto);

    List<TransactionAuditResponseDto> getAuditHistory(Long transactionId);
}
