package com.cib.approval.enums;

public enum ApprovalStatus {
    PENDING,
    APPROVED,
    REJECTED,
    RETURNED_FOR_MODIFICATION
}
