package com.cib.approval.mapper;

import com.cib.approval.dto.*;
import com.cib.approval.entity.ApprovalHistory;
import com.cib.approval.entity.ApprovalRequest;
import org.springframework.stereotype.Component;

@Component
public class ApprovalMapper {

    public ApprovalRequest toEntity(ApprovalSubmissionRequestDto dto) {
        return ApprovalRequest.builder()
                .transactionId(dto.getTransactionId())
                .customerId(dto.getCustomerId())
                .submittedBy(dto.getSubmittedBy())
                .amount(dto.getAmount())
                .currency(dto.getCurrency())
                .remarks(dto.getRemarks())
                .build();
    }

    public ApprovalResponseDto toResponseDto(ApprovalRequest entity) {
        return ApprovalResponseDto.builder()
                .approvalId(entity.getApprovalId())
                .transactionId(entity.getTransactionId())
                .customerId(entity.getCustomerId())
                .submittedBy(entity.getSubmittedBy())
                .amount(entity.getAmount())
                .currency(entity.getCurrency())
                .remarks(entity.getRemarks())
                .status(entity.getStatus())
                .currentLevel(entity.getCurrentLevel())
                .requiredLevels(entity.getRequiredLevels())
                .submittedDate(entity.getSubmittedDate())
                .updatedDate(entity.getUpdatedDate())
                .build();
    }

    public ApprovalHistoryResponseDto toHistoryResponseDto(ApprovalHistory history) {
        return ApprovalHistoryResponseDto.builder()
                .historyId(history.getHistoryId())
                .action(history.getAction())
                .approverId(history.getApproverId())
                .remarks(history.getRemarks())
                .actionDate(history.getActionDate())
                .build();
    }
}
