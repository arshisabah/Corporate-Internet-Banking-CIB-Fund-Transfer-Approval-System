package com.cib.fundtransfer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalSubmissionResponseDto {

    private Long approvalId;
    private Long transactionId;
    private String status;
}
