package com.cib.approval.entity;

import com.cib.approval.enums.ApprovalAction;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "approval_history")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApprovalHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "history_id")
    private Long historyId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "approval_id", nullable = false)
    private ApprovalRequest approvalRequest;

    @Enumerated(EnumType.STRING)
    @Column(name = "action", nullable = false, length = 20)
    private ApprovalAction action;

    @Column(name = "approver_id")
    private Long approverId;

    @Column(name = "remarks", length = 300)
    private String remarks;

    @Column(name = "action_date", updatable = false)
    private LocalDateTime actionDate;

    @PrePersist
    protected void onCreate() {
        this.actionDate = LocalDateTime.now();
    }
}
