package com.cib.approval.constants;

public final class AppConstants {

    private AppConstants() {
    }

    public static final String DEFAULT_PAGE_NUMBER = "0";
    public static final String DEFAULT_PAGE_SIZE = "10";
    public static final String DEFAULT_SORT_BY = "submittedDate";
    public static final String DEFAULT_SORT_DIRECTION = "DESC";

    public static final String APPROVAL_NOT_FOUND = "Approval request not found with id: %s";
    public static final String APPROVAL_NOT_PENDING =
            "Approval request %s cannot be actioned as it is not in PENDING status. Current status: %s";
    public static final String TRANSACTION_STATUS_UPDATE_FAILED =
            "Approval decision was recorded, but updating the transaction status in Fund Transfer Service failed";

    public static final String STATUS_APPROVED = "APPROVED";
    public static final String STATUS_REJECTED = "REJECTED";
    public static final String STATUS_RETURNED = "RETURNED_FOR_MODIFICATION";
}
