package com.cib.fundtransfer.specification;

import com.cib.fundtransfer.entity.FundTransferTransaction;
import com.cib.fundtransfer.enums.TransactionStatus;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public final class TransactionSpecification {

    private TransactionSpecification() {
    }

    public static Specification<FundTransferTransaction> filterBy(Long customerId, Long beneficiaryId, TransactionStatus status) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (customerId != null) {
                predicates.add(cb.equal(root.get("customerId"), customerId));
            }
            if (beneficiaryId != null) {
                predicates.add(cb.equal(root.get("beneficiaryId"), beneficiaryId));
            }
            if (status != null) {
                predicates.add(cb.equal(root.get("status"), status));
            }
            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
