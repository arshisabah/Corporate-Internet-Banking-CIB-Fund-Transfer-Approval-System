package com.cib.beneficiary.service.impl;

import com.cib.beneficiary.constants.AppConstants;
import com.cib.beneficiary.dto.*;
import com.cib.beneficiary.entity.Beneficiary;
import com.cib.beneficiary.enums.BeneficiaryStatus;
import com.cib.beneficiary.exception.BusinessException;
import com.cib.beneficiary.exception.ResourceNotFoundException;
import com.cib.beneficiary.mapper.BeneficiaryMapper;
import com.cib.beneficiary.repository.BeneficiaryRepository;
import com.cib.beneficiary.service.BeneficiaryService;
import com.cib.beneficiary.specification.BeneficiarySpecification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class BeneficiaryServiceImpl implements BeneficiaryService {

    private final BeneficiaryRepository beneficiaryRepository;
    private final BeneficiaryMapper beneficiaryMapper;

    @Override
    @Transactional
    public BeneficiaryResponseDto createBeneficiary(BeneficiaryRequestDto requestDto) {
        if (beneficiaryRepository.existsByCustomerIdAndAccountNumber(requestDto.getCustomerId(), requestDto.getAccountNumber())) {
            throw new BusinessException(String.format(AppConstants.BENEFICIARY_ALREADY_EXISTS, requestDto.getAccountNumber()));
        }
        Beneficiary beneficiary = beneficiaryMapper.toEntity(requestDto);
        Beneficiary saved = beneficiaryRepository.save(beneficiary);
        log.info("Beneficiary {} created successfully for customer {}", saved.getBeneficiaryId(), saved.getCustomerId());
        return beneficiaryMapper.toResponseDto(saved);
    }

    @Override
    public BeneficiaryResponseDto getBeneficiaryById(Long beneficiaryId) {
        return beneficiaryMapper.toResponseDto(fetchBeneficiary(beneficiaryId));
    }

    @Override
    public PageResponse<BeneficiaryResponseDto> searchBeneficiaries(Long customerId, String beneficiaryName,
                                                                     BeneficiaryStatus status, int page, int size,
                                                                     String sortBy, String sortDirection) {
        Sort sort = sortDirection.equalsIgnoreCase("ASC") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Beneficiary> result = beneficiaryRepository.findAll(
                BeneficiarySpecification.filterBy(customerId, beneficiaryName, status), pageable);
        return PageResponse.from(result.map(beneficiaryMapper::toResponseDto));
    }

    @Override
    @Transactional
    public BeneficiaryResponseDto updateBeneficiary(Long beneficiaryId, BeneficiaryRequestDto requestDto) {
        Beneficiary beneficiary = fetchBeneficiary(beneficiaryId);
        beneficiaryMapper.updateEntityFromDto(requestDto, beneficiary);
        Beneficiary updated = beneficiaryRepository.save(beneficiary);
        log.info("Beneficiary {} updated successfully", beneficiaryId);
        return beneficiaryMapper.toResponseDto(updated);
    }

    @Override
    @Transactional
    public void deleteBeneficiary(Long beneficiaryId) {
        Beneficiary beneficiary = fetchBeneficiary(beneficiaryId);
        beneficiaryRepository.delete(beneficiary);
        log.info("Beneficiary {} deleted successfully", beneficiaryId);
    }

    @Override
    public BeneficiaryValidationResponseDto validateBeneficiary(Long beneficiaryId, Long customerId) {
        Optional<Beneficiary> beneficiaryOpt = beneficiaryRepository.findByBeneficiaryIdAndCustomerId(beneficiaryId, customerId);

        if (beneficiaryOpt.isEmpty()) {
            return BeneficiaryValidationResponseDto.builder()
                    .beneficiaryId(beneficiaryId)
                    .valid(false)
                    .message("Beneficiary does not exist for the given customer")
                    .build();
        }

        Beneficiary beneficiary = beneficiaryOpt.get();
        boolean isActive = beneficiary.getStatus() == BeneficiaryStatus.ACTIVE;

        return BeneficiaryValidationResponseDto.builder()
                .beneficiaryId(beneficiary.getBeneficiaryId())
                .valid(isActive)
                .beneficiaryName(beneficiary.getBeneficiaryName())
                .accountNumber(beneficiary.getAccountNumber())
                .message(isActive ? "Beneficiary is active and eligible for fund transfer"
                        : String.format(AppConstants.BENEFICIARY_NOT_ACTIVE, beneficiaryId))
                .build();
    }

    private Beneficiary fetchBeneficiary(Long beneficiaryId) {
        return beneficiaryRepository.findById(beneficiaryId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        String.format(AppConstants.BENEFICIARY_NOT_FOUND, beneficiaryId)));
    }
}
