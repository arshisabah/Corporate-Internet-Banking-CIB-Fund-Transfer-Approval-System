package com.cib.beneficiary.controller;

import com.cib.beneficiary.constants.AppConstants;
import com.cib.beneficiary.dto.*;
import com.cib.beneficiary.enums.BeneficiaryStatus;
import com.cib.beneficiary.service.BeneficiaryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/beneficiaries")
@RequiredArgsConstructor
@Tag(name = "Beneficiary", description = "APIs for managing beneficiaries")
public class BeneficiaryController {

    private final BeneficiaryService beneficiaryService;

    @PostMapping
    @Operation(summary = "Add a new beneficiary")
    public ResponseEntity<ApiResponse<BeneficiaryResponseDto>> createBeneficiary(
            @Valid @RequestBody BeneficiaryRequestDto requestDto) {
        BeneficiaryResponseDto response = beneficiaryService.createBeneficiary(requestDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Beneficiary added successfully", response));
    }

    @GetMapping("/{beneficiaryId}")
    @Operation(summary = "Get beneficiary by id")
    public ResponseEntity<ApiResponse<BeneficiaryResponseDto>> getBeneficiary(@PathVariable Long beneficiaryId) {
        return ResponseEntity.ok(ApiResponse.success(beneficiaryService.getBeneficiaryById(beneficiaryId)));
    }

    @GetMapping
    @Operation(summary = "Search / list beneficiaries with pagination")
    public ResponseEntity<ApiResponse<PageResponse<BeneficiaryResponseDto>>> searchBeneficiaries(
            @RequestParam(required = false) Long customerId,
            @RequestParam(required = false) String beneficiaryName,
            @RequestParam(required = false) BeneficiaryStatus status,
            @RequestParam(defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
            @RequestParam(defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size,
            @RequestParam(defaultValue = AppConstants.DEFAULT_SORT_BY) String sortBy,
            @RequestParam(defaultValue = AppConstants.DEFAULT_SORT_DIRECTION) String sortDirection) {
        return ResponseEntity.ok(ApiResponse.success(
                beneficiaryService.searchBeneficiaries(customerId, beneficiaryName, status, page, size, sortBy, sortDirection)));
    }

    @PutMapping("/{beneficiaryId}")
    @Operation(summary = "Update an existing beneficiary")
    public ResponseEntity<ApiResponse<BeneficiaryResponseDto>> updateBeneficiary(
            @PathVariable Long beneficiaryId, @Valid @RequestBody BeneficiaryRequestDto requestDto) {
        return ResponseEntity.ok(ApiResponse.success("Beneficiary updated successfully",
                beneficiaryService.updateBeneficiary(beneficiaryId, requestDto)));
    }

    @DeleteMapping("/{beneficiaryId}")
    @Operation(summary = "Delete a beneficiary")
    public ResponseEntity<ApiResponse<Void>> deleteBeneficiary(@PathVariable Long beneficiaryId) {
        beneficiaryService.deleteBeneficiary(beneficiaryId);
        return ResponseEntity.ok(ApiResponse.success("Beneficiary deleted successfully", null));
    }

    @GetMapping("/{beneficiaryId}/validate")
    @Operation(summary = "Validate that a beneficiary is active for a given customer (used internally by Fund Transfer Service)")
    public ResponseEntity<ApiResponse<BeneficiaryValidationResponseDto>> validateBeneficiary(
            @PathVariable Long beneficiaryId, @RequestParam Long customerId) {
        return ResponseEntity.ok(ApiResponse.success(
                beneficiaryService.validateBeneficiary(beneficiaryId, customerId)));
    }
}
