package com.cib.fundtransfer.mapper;

import com.cib.fundtransfer.dto.TransactionAuditResponseDto;
import com.cib.fundtransfer.dto.TransactionRequestDto;
import com.cib.fundtransfer.dto.TransactionResponseDto;
import com.cib.fundtransfer.entity.FundTransferTransaction;
import com.cib.fundtransfer.entity.TransactionAudit;
import org.springframework.stereotype.Component;

@Component
public class TransactionMapper {

    public FundTransferTransaction toEntity(TransactionRequestDto dto) {
        return FundTransferTransaction.builder()
                .customerId(dto.getCustomerId())
                .initiatedBy(dto.getInitiatedBy())
                .beneficiaryId(dto.getBeneficiaryId())
                .amount(dto.getAmount())
                .currency(dto.getCurrency())
                .remarks(dto.getRemarks())
                .build();
    }

    public TransactionResponseDto toResponseDto(FundTransferTransaction entity) {
        return TransactionResponseDto.builder()
                .transactionId(entity.getTransactionId())
                .customerId(entity.getCustomerId())
                .initiatedBy(entity.getInitiatedBy())
                .beneficiaryId(entity.getBeneficiaryId())
                .beneficiaryName(entity.getBeneficiaryName())
                .amount(entity.getAmount())
                .currency(entity.getCurrency())
                .remarks(entity.getRemarks())
                .status(entity.getStatus())
                .approvalReferenceId(entity.getApprovalReferenceId())
                .createdDate(entity.getCreatedDate())
                .updatedDate(entity.getUpdatedDate())
                .build();
    }

    public TransactionAuditResponseDto toAuditResponseDto(TransactionAudit audit) {
        return TransactionAuditResponseDto.builder()
                .auditId(audit.getAuditId())
                .previousStatus(audit.getPreviousStatus())
                .newStatus(audit.getNewStatus())
                .changedBy(audit.getChangedBy())
                .remarks(audit.getRemarks())
                .changedDate(audit.getChangedDate())
                .build();
    }

    public void updateEntityFromDto(TransactionRequestDto dto, FundTransferTransaction entity) {
        entity.setBeneficiaryId(dto.getBeneficiaryId());
        entity.setAmount(dto.getAmount());
        entity.setCurrency(dto.getCurrency());
        entity.setRemarks(dto.getRemarks());
    }
}
