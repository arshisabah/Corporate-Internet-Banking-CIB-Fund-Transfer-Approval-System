package com.cib.customer.mapper;

import com.cib.customer.dto.UserRequestDto;
import com.cib.customer.dto.UserResponseDto;
import com.cib.customer.entity.CorporateCustomer;
import com.cib.customer.entity.CorporateUser;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {

    public CorporateUser toEntity(UserRequestDto dto, CorporateCustomer customer) {
        return CorporateUser.builder()
                .customer(customer)
                .username(dto.getUsername())
                .email(dto.getEmail())
                .role(dto.getRole())
                .status(dto.getStatus())
                .build();
    }

    public UserResponseDto toResponseDto(CorporateUser entity) {
        return UserResponseDto.builder()
                .userId(entity.getUserId())
                .customerId(entity.getCustomer().getCustomerId())
                .username(entity.getUsername())
                .email(entity.getEmail())
                .role(entity.getRole())
                .status(entity.getStatus())
                .createdDate(entity.getCreatedDate())
                .build();
    }

    public void updateEntityFromDto(UserRequestDto dto, CorporateUser entity) {
        entity.setUsername(dto.getUsername());
        entity.setEmail(dto.getEmail());
        entity.setRole(dto.getRole());
        if (dto.getStatus() != null) {
            entity.setStatus(dto.getStatus());
        }
    }
}
