# REST API Design

Base convention: `/api/v1/{resource}`. All responses are wrapped in a consistent envelope:

```json
{
  "success": true,
  "message": "Request processed successfully",
  "data": { },
  "timestamp": "2026-07-21T10:15:30"
}
```

Errors follow the same shape via a `GlobalExceptionHandler` in every service:

```json
{
  "success": false,
  "message": "Validation failed",
  "status": 400,
  "path": "/api/v1/transactions",
  "errors": ["Amount must be greater than zero"],
  "timestamp": "2026-07-21T10:15:30"
}
```

Interactive Swagger UI is available per service at `/swagger-ui.html` (springdoc-openapi).

---

## 1. Customer Service (`:8081`)

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/customers` | Create a corporate customer |
| GET | `/api/v1/customers/{customerId}` | Get customer by id |
| GET | `/api/v1/customers?customerName=&cif=&status=&page=&size=&sortBy=&sortDirection=` | Search/list customers (paginated, Specification-based filter) |
| PUT | `/api/v1/customers/{customerId}` | Update a customer |
| DELETE | `/api/v1/customers/{customerId}` | Delete a customer |
| POST | `/api/v1/customers/{customerId}/users` | Create a corporate user under a customer |
| GET | `/api/v1/customers/{customerId}/users?page=&size=` | List users for a customer |
| GET | `/api/v1/users/{userId}` | Get a corporate user by id |
| PUT | `/api/v1/users/{userId}` | Update a corporate user |
| DELETE | `/api/v1/users/{userId}` | Delete a corporate user |

---

## 2. Beneficiary Service (`:8082`)

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/beneficiaries` | Add a beneficiary |
| GET | `/api/v1/beneficiaries/{beneficiaryId}` | Get beneficiary by id |
| GET | `/api/v1/beneficiaries?customerId=&beneficiaryName=&status=&page=&size=&sortBy=&sortDirection=` | Search/list beneficiaries |
| PUT | `/api/v1/beneficiaries/{beneficiaryId}` | Update a beneficiary |
| DELETE | `/api/v1/beneficiaries/{beneficiaryId}` | Delete a beneficiary |
| GET | `/api/v1/beneficiaries/{beneficiaryId}/validate?customerId=` | **Internal** — validates the beneficiary belongs to the customer and is ACTIVE. Called by Fund Transfer Service via Feign before every transfer. |

---

## 3. Fund Transfer Service (`:8083`)

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/transactions` | Initiate a fund transfer. Validates the beneficiary (via Feign → Beneficiary Service) and submits the transaction into the approval workflow (via Feign → Approval Service) |
| GET | `/api/v1/transactions/{transactionId}` | Get a transaction by id |
| GET | `/api/v1/transactions?customerId=&beneficiaryId=&status=&page=&size=&sortBy=&sortDirection=` | Transaction history, paginated & filterable |
| PUT | `/api/v1/transactions/{transactionId}` | Modify a REJECTED / RETURNED_FOR_MODIFICATION transaction and resubmit for approval |
| PATCH | `/api/v1/transactions/{transactionId}/status` | **Internal** — updates transaction status; called back by Approval Service after a decision |
| GET | `/api/v1/transactions/{transactionId}/audit-history` | Full status-change audit trail for a transaction |

**Transaction status lifecycle**

```
INITIATED → PENDING_APPROVAL → APPROVED/EXECUTED
                              → REJECTED
                              → RETURNED_FOR_MODIFICATION → (modify) → INITIATED → PENDING_APPROVAL → ...
```

---

## 4. Approval Service (`:8084`)

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/approvals` | **Internal** — receive a transaction submitted for approval (called by Fund Transfer Service) |
| GET | `/api/v1/approvals/{approvalId}` | Get an approval request by id |
| GET | `/api/v1/approvals?customerId=&status=&page=&size=` | List approval requests (e.g. pending queue) |
| POST | `/api/v1/approvals/{approvalId}/approve` | Approve a pending request. On final level, calls back Fund Transfer Service to mark the transaction EXECUTED |
| POST | `/api/v1/approvals/{approvalId}/reject` | Reject a pending request; calls back Fund Transfer Service to mark the transaction REJECTED |
| POST | `/api/v1/approvals/{approvalId}/return` | Return a pending request for modification; calls back Fund Transfer Service to mark RETURNED_FOR_MODIFICATION |
| GET | `/api/v1/approvals/{approvalId}/history` | Full maker-checker-approver decision history for an approval request |

---

## 5. Sample Payloads

**Initiate Transfer** — `POST /api/v1/transactions`
```json
{
  "customerId": 101,
  "initiatedBy": 501,
  "beneficiaryId": 301,
  "amount": 250000.00,
  "currency": "INR",
  "remarks": "Vendor payment - invoice INV-2026-0456"
}
```

**Approve** — `POST /api/v1/approvals/{approvalId}/approve`
```json
{
  "approverId": 601,
  "remarks": "Verified against invoice, approved"
}
```

**Return for modification** — `POST /api/v1/approvals/{approvalId}/return`
```json
{
  "approverId": 601,
  "remarks": "Amount does not match the invoice attached, please correct"
}
```
