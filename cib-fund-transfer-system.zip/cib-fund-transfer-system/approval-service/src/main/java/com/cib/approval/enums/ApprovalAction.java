package com.cib.approval.enums;

public enum ApprovalAction {
    SUBMITTED,
    APPROVE,
    REJECT,
    RETURN
}
