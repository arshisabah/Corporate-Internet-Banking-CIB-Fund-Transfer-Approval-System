package com.cib.customer.service;

import com.cib.customer.dto.PageResponse;
import com.cib.customer.dto.UserRequestDto;
import com.cib.customer.dto.UserResponseDto;

public interface CorporateUserService {

    UserResponseDto createUser(Long customerId, UserRequestDto requestDto);

    UserResponseDto getUserById(Long userId);

    PageResponse<UserResponseDto> getUsersByCustomer(Long customerId, int page, int size);

    UserResponseDto updateUser(Long userId, UserRequestDto requestDto);

    void deleteUser(Long userId);
}
