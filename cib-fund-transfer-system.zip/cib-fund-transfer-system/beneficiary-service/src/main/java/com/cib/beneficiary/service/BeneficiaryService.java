package com.cib.beneficiary.service;

import com.cib.beneficiary.dto.*;
import com.cib.beneficiary.enums.BeneficiaryStatus;

public interface BeneficiaryService {

    BeneficiaryResponseDto createBeneficiary(BeneficiaryRequestDto requestDto);

    BeneficiaryResponseDto getBeneficiaryById(Long beneficiaryId);

    PageResponse<BeneficiaryResponseDto> searchBeneficiaries(Long customerId, String beneficiaryName,
                                                              BeneficiaryStatus status, int page, int size,
                                                              String sortBy, String sortDirection);

    BeneficiaryResponseDto updateBeneficiary(Long beneficiaryId, BeneficiaryRequestDto requestDto);

    void deleteBeneficiary(Long beneficiaryId);

    BeneficiaryValidationResponseDto validateBeneficiary(Long beneficiaryId, Long customerId);
}
