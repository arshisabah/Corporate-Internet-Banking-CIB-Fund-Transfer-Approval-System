package com.cib.fundtransfer.repository;

import com.cib.fundtransfer.entity.FundTransferTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface FundTransferTransactionRepository
        extends JpaRepository<FundTransferTransaction, Long>, JpaSpecificationExecutor<FundTransferTransaction> {
}
