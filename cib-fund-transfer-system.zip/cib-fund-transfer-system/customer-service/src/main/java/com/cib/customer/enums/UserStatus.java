package com.cib.customer.enums;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    LOCKED
}
