package com.cib.fundtransfer.dto;

import com.cib.fundtransfer.enums.TransactionStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionStatusUpdateDto {

    @NotNull(message = "New status is required")
    private TransactionStatus newStatus;

    private Long approvalReferenceId;

    private String changedBy;

    private String remarks;
}
