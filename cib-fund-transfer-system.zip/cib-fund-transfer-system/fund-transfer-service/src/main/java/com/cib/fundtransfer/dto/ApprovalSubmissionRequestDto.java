package com.cib.fundtransfer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalSubmissionRequestDto {

    private Long transactionId;
    private Long customerId;
    private Long submittedBy;
    private BigDecimal amount;
    private String currency;
    private String remarks;
}
