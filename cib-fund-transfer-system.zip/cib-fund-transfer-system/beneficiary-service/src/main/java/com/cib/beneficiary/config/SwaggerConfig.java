package com.cib.beneficiary.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI beneficiaryServiceOpenAPI() {
        return new OpenAPI().info(new Info()
                .title("Beneficiary Service API")
                .description("APIs for managing corporate beneficiaries and beneficiary validation")
                .version("v1.0.0"));
    }
}
