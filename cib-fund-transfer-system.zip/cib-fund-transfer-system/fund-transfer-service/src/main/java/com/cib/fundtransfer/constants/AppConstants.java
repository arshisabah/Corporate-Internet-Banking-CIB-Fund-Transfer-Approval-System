package com.cib.fundtransfer.constants;

public final class AppConstants {

    private AppConstants() {
    }

    public static final String DEFAULT_PAGE_NUMBER = "0";
    public static final String DEFAULT_PAGE_SIZE = "10";
    public static final String DEFAULT_SORT_BY = "createdDate";
    public static final String DEFAULT_SORT_DIRECTION = "DESC";

    public static final String TRANSACTION_NOT_FOUND = "Transaction not found with id: %s";
    public static final String BENEFICIARY_VALIDATION_FAILED = "Beneficiary validation failed: %s";
    public static final String BENEFICIARY_SERVICE_UNAVAILABLE =
            "Unable to validate beneficiary at this time. Please try again later";
    public static final String INVALID_STATE_FOR_MODIFICATION =
            "Transaction %s cannot be modified in its current status: %s. Only REJECTED or RETURNED_FOR_MODIFICATION transactions can be edited";
    public static final String INVALID_STATE_FOR_SUBMISSION =
            "Transaction %s cannot be submitted for approval in its current status: %s";
    public static final String SYSTEM_USER = "SYSTEM";
}
