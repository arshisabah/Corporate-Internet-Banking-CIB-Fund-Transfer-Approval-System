package com.cib.fundtransfer.client;

import com.cib.fundtransfer.dto.ApiResponse;
import com.cib.fundtransfer.dto.ApprovalSubmissionRequestDto;
import com.cib.fundtransfer.dto.ApprovalSubmissionResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Feign client used to submit fund transfer transactions to the Approval Service
 * for the configured approval workflow.
 */
@FeignClient(name = "approval-service")
public interface ApprovalServiceClient {

    @PostMapping("/api/v1/approvals")
    ApiResponse<ApprovalSubmissionResponseDto> submitForApproval(@RequestBody ApprovalSubmissionRequestDto requestDto);
}
