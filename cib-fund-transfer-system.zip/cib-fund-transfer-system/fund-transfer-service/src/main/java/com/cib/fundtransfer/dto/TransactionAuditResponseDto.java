package com.cib.fundtransfer.dto;

import com.cib.fundtransfer.enums.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionAuditResponseDto {

    private Long auditId;
    private TransactionStatus previousStatus;
    private TransactionStatus newStatus;
    private String changedBy;
    private String remarks;
    private LocalDateTime changedDate;
}
