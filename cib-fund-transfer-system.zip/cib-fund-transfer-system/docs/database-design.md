# Database Design — ER Diagrams & Table Definitions

Each microservice owns an isolated schema/database. There are **no cross-database foreign keys** —
cross-service references (e.g. `customer_id` inside `beneficiary_service`) are logical references only,
resolved at runtime via REST/Feign calls, never via SQL joins across schemas.

## 1. Customer Service — `customer_db`

```
┌────────────────────────────┐          ┌───────────────────────────┐
│     corporate_customer      │          │       corporate_user        │
├────────────────────────────┤          ├───────────────────────────┤
│ PK customer_id (BIGINT)     │ 1     N  │ PK user_id (BIGINT)         │
│    customer_name            │─────────▶│ FK customer_id (BIGINT)     │
│ UQ cif                      │          │    username                 │
│    registration_number      │          │ UQ email                    │
│    address                  │          │    role (ENUM)              │
│    email                    │          │    status (ENUM)            │
│    phone_number             │          │    created_date             │
│    status (ENUM)            │          │    updated_date             │
│    created_date             │          └───────────────────────────┘
│    updated_date             │
└────────────────────────────┘
```

**corporate_customer**
| Column | Type | Constraints |
|---|---|---|
| customer_id | BIGINT | PK, auto-increment |
| customer_name | VARCHAR(150) | NOT NULL |
| cif | VARCHAR(30) | NOT NULL, UNIQUE |
| registration_number | VARCHAR(50) | |
| address | VARCHAR(300) | |
| email | VARCHAR(100) | |
| phone_number | VARCHAR(20) | |
| status | VARCHAR(20) | NOT NULL — ACTIVE / INACTIVE / SUSPENDED |
| created_date | TIMESTAMP | NOT NULL |
| updated_date | TIMESTAMP | |

**corporate_user**
| Column | Type | Constraints |
|---|---|---|
| user_id | BIGINT | PK, auto-increment |
| customer_id | BIGINT | FK → corporate_customer.customer_id |
| username | VARCHAR(80) | NOT NULL |
| email | VARCHAR(100) | NOT NULL, UNIQUE |
| role | VARCHAR(20) | NOT NULL — MAKER / CHECKER / APPROVER / ADMIN |
| status | VARCHAR(20) | NOT NULL — ACTIVE / INACTIVE / LOCKED |
| created_date | TIMESTAMP | NOT NULL |
| updated_date | TIMESTAMP | |

---

## 2. Beneficiary Service — `beneficiary_db`

```
┌──────────────────────────────────┐
│            beneficiary             │
├──────────────────────────────────┤
│ PK beneficiary_id (BIGINT)         │
│    customer_id (BIGINT) *logical*  │  ── logical ref to customer_db.corporate_customer
│    beneficiary_name                │
│    nickname                        │
│    account_number                  │
│    ifsc_code                       │
│    bank_name                       │
│    email                           │
│    status (ENUM)                   │
│    created_date                    │
│    updated_date                    │
└──────────────────────────────────┘
```

| Column | Type | Constraints |
|---|---|---|
| beneficiary_id | BIGINT | PK, auto-increment |
| customer_id | BIGINT | NOT NULL (logical FK to customer-service) |
| beneficiary_name | VARCHAR(150) | NOT NULL |
| nickname | VARCHAR(80) | |
| account_number | VARCHAR(30) | NOT NULL |
| ifsc_code | VARCHAR(15) | NOT NULL |
| bank_name | VARCHAR(100) | |
| email | VARCHAR(100) | |
| status | VARCHAR(20) | NOT NULL — ACTIVE / INACTIVE / BLOCKED |
| created_date | TIMESTAMP | NOT NULL |
| updated_date | TIMESTAMP | |

Unique business constraint: (customer_id, account_number) enforced in the service layer.

---

## 3. Fund Transfer Service — `fundtransfer_db`

```
┌────────────────────────────────────┐          ┌────────────────────────────────┐
│      fund_transfer_transaction        │          │        transaction_audit          │
├────────────────────────────────────┤          ├────────────────────────────────┤
│ PK transaction_id (BIGINT)            │ 1    N  │ PK audit_id (BIGINT)              │
│    customer_id (BIGINT) *logical*      │────────▶│ FK transaction_id (BIGINT)        │
│    initiated_by (BIGINT) *logical*     │          │    previous_status (ENUM)         │
│    beneficiary_id (BIGINT) *logical*   │          │    new_status (ENUM)              │
│    beneficiary_name (snapshot)         │          │    changed_by                     │
│    amount (DECIMAL 18,2)               │          │    remarks                        │
│    currency                            │          │    changed_date                   │
│    remarks                             │          └────────────────────────────────┘
│    status (ENUM)                       │
│    approval_reference_id *logical*     │  ── logical ref to approval_db.approval_request
│    created_date                        │
│    updated_date                        │
└────────────────────────────────────┘
```

**fund_transfer_transaction**
| Column | Type | Constraints |
|---|---|---|
| transaction_id | BIGINT | PK, auto-increment |
| customer_id | BIGINT | NOT NULL (logical FK to customer-service) |
| initiated_by | BIGINT | NOT NULL (logical FK to corporate_user) |
| beneficiary_id | BIGINT | NOT NULL (logical FK to beneficiary-service) |
| beneficiary_name | VARCHAR(150) | snapshot at time of transfer |
| amount | DECIMAL(18,2) | NOT NULL |
| currency | VARCHAR(5) | NOT NULL |
| remarks | VARCHAR(300) | |
| status | VARCHAR(40) | NOT NULL — INITIATED / PENDING_APPROVAL / APPROVED / REJECTED / RETURNED_FOR_MODIFICATION / EXECUTED / FAILED |
| approval_reference_id | BIGINT | logical FK to approval-service |
| created_date | TIMESTAMP | NOT NULL |
| updated_date | TIMESTAMP | |

**transaction_audit**
| Column | Type | Constraints |
|---|---|---|
| audit_id | BIGINT | PK, auto-increment |
| transaction_id | BIGINT | FK → fund_transfer_transaction.transaction_id |
| previous_status | VARCHAR(40) | nullable (first entry has no previous status) |
| new_status | VARCHAR(40) | NOT NULL |
| changed_by | VARCHAR(80) | |
| remarks | VARCHAR(300) | |
| changed_date | TIMESTAMP | NOT NULL |

---

## 4. Approval Service — `approval_db`

```
┌────────────────────────────────────┐          ┌────────────────────────────────┐
│         approval_request              │          │        approval_history           │
├────────────────────────────────────┤          ├────────────────────────────────┤
│ PK approval_id (BIGINT)               │ 1    N  │ PK history_id (BIGINT)            │
│    transaction_id (BIGINT) *logical*   │────────▶│ FK approval_id (BIGINT)           │
│    customer_id (BIGINT) *logical*      │          │    action (ENUM)                  │
│    submitted_by (BIGINT) *logical*     │          │    approver_id *logical*          │
│    amount (DECIMAL 18,2)               │          │    remarks                        │
│    currency                            │          │    action_date                    │
│    remarks                             │          └────────────────────────────────┘
│    status (ENUM)                       │
│    current_level (INT)                 │
│    required_levels (INT)               │
│    submitted_date                      │
│    updated_date                        │
└────────────────────────────────────┘
```

**approval_request**
| Column | Type | Constraints |
|---|---|---|
| approval_id | BIGINT | PK, auto-increment |
| transaction_id | BIGINT | NOT NULL (logical FK to fund-transfer-service) |
| customer_id | BIGINT | NOT NULL |
| submitted_by | BIGINT | NOT NULL |
| amount | DECIMAL(18,2) | NOT NULL |
| currency | VARCHAR(5) | NOT NULL |
| remarks | VARCHAR(300) | |
| status | VARCHAR(30) | NOT NULL — PENDING / APPROVED / REJECTED / RETURNED_FOR_MODIFICATION |
| current_level | INT | NOT NULL, default 1 |
| required_levels | INT | NOT NULL, computed from workflow config (e.g. amount threshold) |
| submitted_date | TIMESTAMP | NOT NULL |
| updated_date | TIMESTAMP | |

**approval_history**
| Column | Type | Constraints |
|---|---|---|
| history_id | BIGINT | PK, auto-increment |
| approval_id | BIGINT | FK → approval_request.approval_id |
| action | VARCHAR(20) | NOT NULL — SUBMITTED / APPROVE / REJECT / RETURN |
| approver_id | BIGINT | logical FK to corporate_user, nullable for SUBMITTED |
| remarks | VARCHAR(300) | |
| action_date | TIMESTAMP | NOT NULL |
