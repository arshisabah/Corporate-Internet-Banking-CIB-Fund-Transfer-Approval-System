package com.cib.beneficiary.repository;

import com.cib.beneficiary.entity.Beneficiary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface BeneficiaryRepository
        extends JpaRepository<Beneficiary, Long>, JpaSpecificationExecutor<Beneficiary> {

    boolean existsByCustomerIdAndAccountNumber(Long customerId, String accountNumber);

    Optional<Beneficiary> findByBeneficiaryIdAndCustomerId(Long beneficiaryId, Long customerId);
}
