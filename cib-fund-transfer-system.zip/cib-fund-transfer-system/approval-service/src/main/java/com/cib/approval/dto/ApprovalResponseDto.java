package com.cib.approval.dto;

import com.cib.approval.enums.ApprovalStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalResponseDto {

    private Long approvalId;
    private Long transactionId;
    private Long customerId;
    private Long submittedBy;
    private BigDecimal amount;
    private String currency;
    private String remarks;
    private ApprovalStatus status;
    private Integer currentLevel;
    private Integer requiredLevels;
    private LocalDateTime submittedDate;
    private LocalDateTime updatedDate;
}
