package com.cib.customer.service.impl;

import com.cib.customer.constants.AppConstants;
import com.cib.customer.dto.PageResponse;
import com.cib.customer.dto.UserRequestDto;
import com.cib.customer.dto.UserResponseDto;
import com.cib.customer.entity.CorporateCustomer;
import com.cib.customer.entity.CorporateUser;
import com.cib.customer.exception.BusinessException;
import com.cib.customer.exception.ResourceNotFoundException;
import com.cib.customer.mapper.UserMapper;
import com.cib.customer.repository.CorporateCustomerRepository;
import com.cib.customer.repository.CorporateUserRepository;
import com.cib.customer.service.CorporateUserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CorporateUserServiceImpl implements CorporateUserService {

    private final CorporateUserRepository userRepository;
    private final CorporateCustomerRepository customerRepository;
    private final UserMapper userMapper;

    @Override
    @Transactional
    public UserResponseDto createUser(Long customerId, UserRequestDto requestDto) {
        CorporateCustomer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        String.format(AppConstants.CUSTOMER_NOT_FOUND, customerId)));

        if (userRepository.existsByEmail(requestDto.getEmail())) {
            throw new BusinessException(String.format(AppConstants.EMAIL_ALREADY_EXISTS, requestDto.getEmail()));
        }

        CorporateUser user = userMapper.toEntity(requestDto, customer);
        CorporateUser saved = userRepository.save(user);
        log.info("Corporate user {} created successfully for customer {}", saved.getUserId(), customerId);
        return userMapper.toResponseDto(saved);
    }

    @Override
    public UserResponseDto getUserById(Long userId) {
        return userMapper.toResponseDto(fetchUser(userId));
    }

    @Override
    public PageResponse<UserResponseDto> getUsersByCustomer(Long customerId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdDate").descending());
        Page<CorporateUser> result = userRepository.findByCustomer_CustomerId(customerId, pageable);
        return PageResponse.from(result.map(userMapper::toResponseDto));
    }

    @Override
    @Transactional
    public UserResponseDto updateUser(Long userId, UserRequestDto requestDto) {
        CorporateUser user = fetchUser(userId);
        userMapper.updateEntityFromDto(requestDto, user);
        CorporateUser updated = userRepository.save(user);
        log.info("Corporate user {} updated successfully", userId);
        return userMapper.toResponseDto(updated);
    }

    @Override
    @Transactional
    public void deleteUser(Long userId) {
        CorporateUser user = fetchUser(userId);
        userRepository.delete(user);
        log.info("Corporate user {} deleted successfully", userId);
    }

    private CorporateUser fetchUser(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        String.format(AppConstants.USER_NOT_FOUND, userId)));
    }
}
