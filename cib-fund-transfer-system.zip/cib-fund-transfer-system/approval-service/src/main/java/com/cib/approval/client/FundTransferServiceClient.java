package com.cib.approval.client;

import com.cib.approval.dto.ApiResponse;
import com.cib.approval.dto.TransactionStatusUpdateDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Feign client used to call back into the Fund Transfer Service (via Eureka service discovery)
 * to reflect approval decisions on the originating transaction.
 */
@FeignClient(name = "fund-transfer-service")
public interface FundTransferServiceClient {

    @PatchMapping("/api/v1/transactions/{transactionId}/status")
    ApiResponse<Object> updateTransactionStatus(@PathVariable("transactionId") Long transactionId,
                                                 @RequestBody TransactionStatusUpdateDto updateDto);
}
