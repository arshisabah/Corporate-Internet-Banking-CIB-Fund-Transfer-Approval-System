package com.cib.fundtransfer.entity;

import com.cib.fundtransfer.enums.TransactionStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "transaction_audit")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "audit_id")
    private Long auditId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id", nullable = false)
    private FundTransferTransaction transaction;

    @Enumerated(EnumType.STRING)
    @Column(name = "previous_status", length = 40)
    private TransactionStatus previousStatus;

    @Enumerated(EnumType.STRING)
    @Column(name = "new_status", nullable = false, length = 40)
    private TransactionStatus newStatus;

    @Column(name = "changed_by", length = 80)
    private String changedBy;

    @Column(name = "remarks", length = 300)
    private String remarks;

    @Column(name = "changed_date", updatable = false)
    private LocalDateTime changedDate;

    @PrePersist
    protected void onCreate() {
        this.changedDate = LocalDateTime.now();
    }
}
