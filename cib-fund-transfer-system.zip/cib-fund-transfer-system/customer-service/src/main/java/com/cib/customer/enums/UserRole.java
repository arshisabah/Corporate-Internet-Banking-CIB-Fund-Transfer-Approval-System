package com.cib.customer.enums;

public enum UserRole {
    MAKER,
    CHECKER,
    APPROVER,
    ADMIN
}
