package com.cib.beneficiary.specification;

import com.cib.beneficiary.entity.Beneficiary;
import com.cib.beneficiary.enums.BeneficiaryStatus;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public final class BeneficiarySpecification {

    private BeneficiarySpecification() {
    }

    public static Specification<Beneficiary> filterBy(Long customerId, String beneficiaryName, BeneficiaryStatus status) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (customerId != null) {
                predicates.add(cb.equal(root.get("customerId"), customerId));
            }
            if (beneficiaryName != null && !beneficiaryName.isBlank()) {
                predicates.add(cb.like(cb.lower(root.get("beneficiaryName")), "%" + beneficiaryName.toLowerCase() + "%"));
            }
            if (status != null) {
                predicates.add(cb.equal(root.get("status"), status));
            }
            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
