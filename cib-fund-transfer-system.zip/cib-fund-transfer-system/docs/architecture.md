# CIB Fund Transfer & Approval System — Microservices Architecture

## 1. Overview

The system is decomposed into four independent, single-responsibility Spring Boot microservices,
each owning its own database, registered with a Eureka Service Discovery server, and communicating
synchronously through OpenFeign clients resolved by service name (never hardcoded host/port).

| Service | Port | Responsibility | Own Database |
|---|---|---|---|
| eureka-server | 8761 | Service registry / discovery | none |
| customer-service | 8081 | Corporate customer & corporate user master data | customer_db |
| beneficiary-service | 8082 | Beneficiary CRUD + beneficiary validation | beneficiary_db |
| fund-transfer-service | 8083 | Transfer initiation, history, status tracking, audit trail | fundtransfer_db |
| approval-service | 8084 | Approval workflow (approve/reject/return), approval history | approval_db |

## 2. Architecture Diagram

```
                                   ┌───────────────────────┐
                                   │     Eureka Server      │
                                   │   (Service Registry)   │
                                   │        :8761           │
                                   └───────────▲───────────┘
                     register/discover │ │ │ │ (all services)
              ┌─────────────────────────┼─┼─┼─┼─────────────────────────┐
              │                         │ │ │ │                         │
    ┌─────────┴────────┐     ┌──────────┴─┴─┴─┴───────┐      ┌──────────┴─────────┐
    │  Customer Service │     │  Beneficiary Service    │      │  Approval Service   │
    │      :8081        │     │        :8082            │      │       :8084         │
    │  (customer_db)     │     │   (beneficiary_db)      │      │   (approval_db)     │
    └────────────────────┘     └───────────▲─────────────┘      └──────────▲──────────┘
                                            │ Feign: validateBeneficiary     │ Feign: submitForApproval
                                            │                                │ Feign: updateTransactionStatus (callback)
                                 ┌──────────┴────────────────────────────────┴──────────┐
                                 │              Fund Transfer Service                    │
                                 │                    :8083                              │
                                 │               (fundtransfer_db)                       │
                                 └────────────────────────────────────────────────────────┘
                                            ▲
                                            │ REST (HTTPS) via API Gateway / direct
                                 ┌──────────┴──────────┐
                                 │   Corporate Banking  │
                                 │   Web / Mobile Client │
                                 └───────────────────────┘
```

## 3. Interaction Flow (Happy Path)

1. Corporate user (maker) calls `POST /api/v1/transactions` on **Fund Transfer Service**.
2. Fund Transfer Service calls **Beneficiary Service** (`GET /api/v1/beneficiaries/{id}/validate`) via
   Feign, using the `beneficiary-service` logical name resolved through Eureka.
   * If the beneficiary is not ACTIVE, the request is rejected with `409 Conflict` and no transaction is created against the workflow.
3. On successful validation, Fund Transfer Service persists the transaction (`INITIATED`), records an audit entry,
   then calls **Approval Service** (`POST /api/v1/approvals`) via Feign to enqueue it into the configured
   approval workflow. Transaction status moves to `PENDING_APPROVAL`.
4. An approver calls `POST /api/v1/approvals/{id}/approve|reject|return` on **Approval Service**.
   * Every decision is written to `approval_history` (immutable audit log).
   * Approval Service calls back into **Fund Transfer Service** (`PATCH /api/v1/transactions/{id}/status`)
     via Feign to reflect the decision (`EXECUTED`, `REJECTED`, or `RETURNED_FOR_MODIFICATION`).
5. Every transition on the Fund Transfer Service side is written to `transaction_audit`, giving a complete,
   queryable audit trail (`GET /api/v1/transactions/{id}/audit-history`).
6. If `RETURNED_FOR_MODIFICATION` or `REJECTED`, the maker can call
   `PUT /api/v1/transactions/{id}` to correct and resubmit — this re-validates the beneficiary and
   re-enters the approval workflow from level 1.

## 4. Design Principles Applied

- **Database per service** — no service reaches into another's schema; all cross-service reads go through REST/Feign.
- **Single responsibility** — Customer/User master data, Beneficiary master data, Transaction lifecycle,
  and Approval workflow are each isolated in their own bounded context.
- **Service Discovery** — all inter-service calls use Eureka logical names (`@FeignClient(name = "beneficiary-service")`),
  so no IPs/ports are hardcoded and services can scale horizontally behind the registry.
- **Config externalization** — `application.yml` + per-environment `dev/qa/prod` profiles; datasource,
  Eureka URL, and log levels are all environment-driven and none are hardcoded in code.
- **Resilience** — Feign calls are wrapped in try/catch translating `FeignException` into a domain-specific
  `ServiceUnavailableException` / `BusinessException`, handled centrally by a `@RestControllerAdvice`.
- **Auditability** — every status transition (both on the transaction and on the approval request) is
  captured as an immutable history row, satisfying the "complete audit history" business rule.

## 5. Recommended Production Additions (not required for this exercise but noted)

- API Gateway (Spring Cloud Gateway) in front of all four services for a single entry point, auth, and rate-limiting.
- Centralized configuration server (Spring Cloud Config) instead of profile-only externalization.
- Message broker (Kafka/RabbitMQ) for the approval-decision → transaction-status-update callback, to
  decouple the synchronous Feign call and improve resilience under load (event-driven alternative to the
  current synchronous Feign design used here for simplicity/clarity).
- Circuit breaker (Resilience4j) around the Feign clients.
