package com.cib.beneficiary.dto;

import com.cib.beneficiary.enums.BeneficiaryStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryResponseDto {

    private Long beneficiaryId;
    private Long customerId;
    private String beneficiaryName;
    private String nickname;
    private String accountNumber;
    private String ifscCode;
    private String bankName;
    private String email;
    private BeneficiaryStatus status;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
}
