package com.cib.approval.dto;

import com.cib.approval.enums.ApprovalAction;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalHistoryResponseDto {

    private Long historyId;
    private ApprovalAction action;
    private Long approverId;
    private String remarks;
    private LocalDateTime actionDate;
}
