package com.cib.beneficiary.dto;

import com.cib.beneficiary.enums.BeneficiaryStatus;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryRequestDto {

    @NotNull(message = "Customer id is required")
    private Long customerId;

    @NotBlank(message = "Beneficiary name is required")
    @Size(max = 150, message = "Beneficiary name must not exceed 150 characters")
    private String beneficiaryName;

    @Size(max = 80, message = "Nickname must not exceed 80 characters")
    private String nickname;

    @NotBlank(message = "Account number is required")
    @Pattern(regexp = "^[0-9]{9,18}$", message = "Account number must be 9 to 18 digits")
    private String accountNumber;

    @NotBlank(message = "IFSC code is required")
    @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$", message = "IFSC code format is invalid")
    private String ifscCode;

    @Size(max = 100, message = "Bank name must not exceed 100 characters")
    private String bankName;

    @Email(message = "Email must be valid")
    private String email;

    private BeneficiaryStatus status;
}
