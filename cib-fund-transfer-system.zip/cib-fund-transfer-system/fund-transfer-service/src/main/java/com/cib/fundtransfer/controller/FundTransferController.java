package com.cib.fundtransfer.controller;

import com.cib.fundtransfer.constants.AppConstants;
import com.cib.fundtransfer.dto.*;
import com.cib.fundtransfer.enums.TransactionStatus;
import com.cib.fundtransfer.service.FundTransferService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/transactions")
@RequiredArgsConstructor
@Tag(name = "Fund Transfer", description = "APIs for initiating and tracking corporate fund transfers")
public class FundTransferController {

    private final FundTransferService fundTransferService;

    @PostMapping
    @Operation(summary = "Initiate a new fund transfer (validates beneficiary and submits for approval)")
    public ResponseEntity<ApiResponse<TransactionResponseDto>> initiateTransfer(
            @Valid @RequestBody TransactionRequestDto requestDto) {
        TransactionResponseDto response = fundTransferService.initiateTransfer(requestDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Fund transfer initiated and submitted for approval", response));
    }

    @GetMapping("/{transactionId}")
    @Operation(summary = "Get a fund transfer transaction by id")
    public ResponseEntity<ApiResponse<TransactionResponseDto>> getTransaction(@PathVariable Long transactionId) {
        return ResponseEntity.ok(ApiResponse.success(fundTransferService.getTransactionById(transactionId)));
    }

    @GetMapping
    @Operation(summary = "View transaction history with filters and pagination")
    public ResponseEntity<ApiResponse<PageResponse<TransactionResponseDto>>> getTransactionHistory(
            @RequestParam(required = false) Long customerId,
            @RequestParam(required = false) Long beneficiaryId,
            @RequestParam(required = false) TransactionStatus status,
            @RequestParam(defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
            @RequestParam(defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size,
            @RequestParam(defaultValue = AppConstants.DEFAULT_SORT_BY) String sortBy,
            @RequestParam(defaultValue = AppConstants.DEFAULT_SORT_DIRECTION) String sortDirection) {
        return ResponseEntity.ok(ApiResponse.success(fundTransferService.getTransactionHistory(
                customerId, beneficiaryId, status, page, size, sortBy, sortDirection)));
    }

    @PutMapping("/{transactionId}")
    @Operation(summary = "Modify a rejected/returned transaction and resubmit for approval")
    public ResponseEntity<ApiResponse<TransactionResponseDto>> modifyAndResubmit(
            @PathVariable Long transactionId, @Valid @RequestBody TransactionRequestDto requestDto) {
        return ResponseEntity.ok(ApiResponse.success("Transaction modified and resubmitted for approval",
                fundTransferService.modifyAndResubmit(transactionId, requestDto)));
    }

    @PatchMapping("/{transactionId}/status")
    @Operation(summary = "Update transaction status (called internally by the Approval Service)")
    public ResponseEntity<ApiResponse<TransactionResponseDto>> updateStatus(
            @PathVariable Long transactionId, @Valid @RequestBody TransactionStatusUpdateDto updateDto) {
        return ResponseEntity.ok(ApiResponse.success("Transaction status updated successfully",
                fundTransferService.updateTransactionStatus(transactionId, updateDto)));
    }

    @GetMapping("/{transactionId}/audit-history")
    @Operation(summary = "Get the complete audit trail for a transaction")
    public ResponseEntity<ApiResponse<List<TransactionAuditResponseDto>>> getAuditHistory(@PathVariable Long transactionId) {
        return ResponseEntity.ok(ApiResponse.success(fundTransferService.getAuditHistory(transactionId)));
    }
}
