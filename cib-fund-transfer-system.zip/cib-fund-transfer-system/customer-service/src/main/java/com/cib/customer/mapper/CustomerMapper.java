package com.cib.customer.mapper;

import com.cib.customer.dto.CustomerRequestDto;
import com.cib.customer.dto.CustomerResponseDto;
import com.cib.customer.entity.CorporateCustomer;
import org.springframework.stereotype.Component;

@Component
public class CustomerMapper {

    public CorporateCustomer toEntity(CustomerRequestDto dto) {
        return CorporateCustomer.builder()
                .customerName(dto.getCustomerName())
                .cif(dto.getCif())
                .registrationNumber(dto.getRegistrationNumber())
                .address(dto.getAddress())
                .email(dto.getEmail())
                .phoneNumber(dto.getPhoneNumber())
                .status(dto.getStatus())
                .build();
    }

    public CustomerResponseDto toResponseDto(CorporateCustomer entity) {
        return CustomerResponseDto.builder()
                .customerId(entity.getCustomerId())
                .customerName(entity.getCustomerName())
                .cif(entity.getCif())
                .registrationNumber(entity.getRegistrationNumber())
                .address(entity.getAddress())
                .email(entity.getEmail())
                .phoneNumber(entity.getPhoneNumber())
                .status(entity.getStatus())
                .createdDate(entity.getCreatedDate())
                .updatedDate(entity.getUpdatedDate())
                .build();
    }

    public void updateEntityFromDto(CustomerRequestDto dto, CorporateCustomer entity) {
        entity.setCustomerName(dto.getCustomerName());
        entity.setRegistrationNumber(dto.getRegistrationNumber());
        entity.setAddress(dto.getAddress());
        entity.setEmail(dto.getEmail());
        entity.setPhoneNumber(dto.getPhoneNumber());
        if (dto.getStatus() != null) {
            entity.setStatus(dto.getStatus());
        }
    }
}
