package com.cib.customer.dto;

import com.cib.customer.enums.CustomerStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerResponseDto {

    private Long customerId;
    private String customerName;
    private String cif;
    private String registrationNumber;
    private String address;
    private String email;
    private String phoneNumber;
    private CustomerStatus status;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
}
