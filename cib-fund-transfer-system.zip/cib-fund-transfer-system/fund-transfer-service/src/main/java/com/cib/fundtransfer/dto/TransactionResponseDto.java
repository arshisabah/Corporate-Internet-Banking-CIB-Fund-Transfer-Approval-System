package com.cib.fundtransfer.dto;

import com.cib.fundtransfer.enums.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionResponseDto {

    private Long transactionId;
    private Long customerId;
    private Long initiatedBy;
    private Long beneficiaryId;
    private String beneficiaryName;
    private BigDecimal amount;
    private String currency;
    private String remarks;
    private TransactionStatus status;
    private Long approvalReferenceId;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
}
