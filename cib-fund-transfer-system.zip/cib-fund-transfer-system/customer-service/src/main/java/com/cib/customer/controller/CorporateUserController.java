package com.cib.customer.controller;

import com.cib.customer.dto.ApiResponse;
import com.cib.customer.dto.PageResponse;
import com.cib.customer.dto.UserRequestDto;
import com.cib.customer.dto.UserResponseDto;
import com.cib.customer.service.CorporateUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Tag(name = "Corporate User", description = "APIs for managing corporate users")
public class CorporateUserController {

    private final CorporateUserService userService;

    @PostMapping("/api/v1/customers/{customerId}/users")
    @Operation(summary = "Create a corporate user under a customer")
    public ResponseEntity<ApiResponse<UserResponseDto>> createUser(
            @PathVariable Long customerId, @Valid @RequestBody UserRequestDto requestDto) {
        UserResponseDto response = userService.createUser(customerId, requestDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Corporate user created successfully", response));
    }

    @GetMapping("/api/v1/customers/{customerId}/users")
    @Operation(summary = "List corporate users for a customer")
    public ResponseEntity<ApiResponse<PageResponse<UserResponseDto>>> getUsersByCustomer(
            @PathVariable Long customerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(ApiResponse.success(userService.getUsersByCustomer(customerId, page, size)));
    }

    @GetMapping("/api/v1/users/{userId}")
    @Operation(summary = "Get corporate user by id")
    public ResponseEntity<ApiResponse<UserResponseDto>> getUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success(userService.getUserById(userId)));
    }

    @PutMapping("/api/v1/users/{userId}")
    @Operation(summary = "Update a corporate user")
    public ResponseEntity<ApiResponse<UserResponseDto>> updateUser(
            @PathVariable Long userId, @Valid @RequestBody UserRequestDto requestDto) {
        return ResponseEntity.ok(ApiResponse.success("Corporate user updated successfully",
                userService.updateUser(userId, requestDto)));
    }

    @DeleteMapping("/api/v1/users/{userId}")
    @Operation(summary = "Delete a corporate user")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable Long userId) {
        userService.deleteUser(userId);
        return ResponseEntity.ok(ApiResponse.success("Corporate user deleted successfully", null));
    }
}
