package com.cib.fundtransfer.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI fundTransferServiceOpenAPI() {
        return new OpenAPI().info(new Info()
                .title("Fund Transfer Service API")
                .description("APIs for initiating fund transfers, viewing history and tracking transaction status")
                .version("v1.0.0"));
    }
}
