package com.cib.customer.repository;

import com.cib.customer.entity.CorporateCustomer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface CorporateCustomerRepository
        extends JpaRepository<CorporateCustomer, Long>, JpaSpecificationExecutor<CorporateCustomer> {

    Optional<CorporateCustomer> findByCif(String cif);

    boolean existsByCif(String cif);
}
