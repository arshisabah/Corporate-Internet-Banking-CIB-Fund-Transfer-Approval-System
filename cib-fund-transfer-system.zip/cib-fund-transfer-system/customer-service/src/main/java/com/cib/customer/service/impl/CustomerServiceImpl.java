package com.cib.customer.service.impl;

import com.cib.customer.constants.AppConstants;
import com.cib.customer.dto.CustomerRequestDto;
import com.cib.customer.dto.CustomerResponseDto;
import com.cib.customer.dto.PageResponse;
import com.cib.customer.entity.CorporateCustomer;
import com.cib.customer.enums.CustomerStatus;
import com.cib.customer.exception.BusinessException;
import com.cib.customer.exception.ResourceNotFoundException;
import com.cib.customer.mapper.CustomerMapper;
import com.cib.customer.repository.CorporateCustomerRepository;
import com.cib.customer.service.CustomerService;
import com.cib.customer.specification.CustomerSpecification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CorporateCustomerRepository customerRepository;
    private final CustomerMapper customerMapper;

    @Override
    @Transactional
    public CustomerResponseDto createCustomer(CustomerRequestDto requestDto) {
        if (customerRepository.existsByCif(requestDto.getCif())) {
            throw new BusinessException(String.format(AppConstants.CIF_ALREADY_EXISTS, requestDto.getCif()));
        }
        CorporateCustomer customer = customerMapper.toEntity(requestDto);
        CorporateCustomer saved = customerRepository.save(customer);
        log.info("Corporate customer {} created successfully", saved.getCustomerId());
        return customerMapper.toResponseDto(saved);
    }

    @Override
    public CustomerResponseDto getCustomerById(Long customerId) {
        CorporateCustomer customer = fetchCustomer(customerId);
        return customerMapper.toResponseDto(customer);
    }

    @Override
    public PageResponse<CustomerResponseDto> searchCustomers(String customerName, String cif, CustomerStatus status,
                                                               int page, int size, String sortBy, String sortDirection) {
        Sort sort = sortDirection.equalsIgnoreCase("ASC") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<CorporateCustomer> result = customerRepository.findAll(
                CustomerSpecification.filterBy(customerName, cif, status), pageable);
        return PageResponse.from(result.map(customerMapper::toResponseDto));
    }

    @Override
    @Transactional
    public CustomerResponseDto updateCustomer(Long customerId, CustomerRequestDto requestDto) {
        CorporateCustomer customer = fetchCustomer(customerId);
        customerMapper.updateEntityFromDto(requestDto, customer);
        CorporateCustomer updated = customerRepository.save(customer);
        log.info("Corporate customer {} updated successfully", customerId);
        return customerMapper.toResponseDto(updated);
    }

    @Override
    @Transactional
    public void deleteCustomer(Long customerId) {
        CorporateCustomer customer = fetchCustomer(customerId);
        customerRepository.delete(customer);
        log.info("Corporate customer {} deleted successfully", customerId);
    }

    private CorporateCustomer fetchCustomer(Long customerId) {
        return customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        String.format(AppConstants.CUSTOMER_NOT_FOUND, customerId)));
    }
}
