package com.cib.customer.repository;

import com.cib.customer.entity.CorporateUser;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CorporateUserRepository extends JpaRepository<CorporateUser, Long> {

    Page<CorporateUser> findByCustomer_CustomerId(Long customerId, Pageable pageable);

    Optional<CorporateUser> findByEmail(String email);

    boolean existsByEmail(String email);
}
