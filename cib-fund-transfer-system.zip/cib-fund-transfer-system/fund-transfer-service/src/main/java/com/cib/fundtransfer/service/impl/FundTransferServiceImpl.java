package com.cib.fundtransfer.service.impl;

import com.cib.fundtransfer.client.ApprovalServiceClient;
import com.cib.fundtransfer.client.BeneficiaryServiceClient;
import com.cib.fundtransfer.constants.AppConstants;
import com.cib.fundtransfer.dto.*;
import com.cib.fundtransfer.entity.FundTransferTransaction;
import com.cib.fundtransfer.entity.TransactionAudit;
import com.cib.fundtransfer.enums.TransactionStatus;
import com.cib.fundtransfer.exception.BusinessException;
import com.cib.fundtransfer.exception.ResourceNotFoundException;
import com.cib.fundtransfer.exception.ServiceUnavailableException;
import com.cib.fundtransfer.mapper.TransactionMapper;
import com.cib.fundtransfer.repository.FundTransferTransactionRepository;
import com.cib.fundtransfer.repository.TransactionAuditRepository;
import com.cib.fundtransfer.service.FundTransferService;
import com.cib.fundtransfer.specification.TransactionSpecification;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class FundTransferServiceImpl implements FundTransferService {

    private static final Set<TransactionStatus> MODIFIABLE_STATUSES =
            EnumSet.of(TransactionStatus.REJECTED, TransactionStatus.RETURNED_FOR_MODIFICATION);

    private final FundTransferTransactionRepository transactionRepository;
    private final TransactionAuditRepository auditRepository;
    private final TransactionMapper transactionMapper;
    private final BeneficiaryServiceClient beneficiaryServiceClient;
    private final ApprovalServiceClient approvalServiceClient;

    @Override
    @Transactional
    public TransactionResponseDto initiateTransfer(TransactionRequestDto requestDto) {
        BeneficiaryValidationResponseDto validation = validateBeneficiary(requestDto.getCustomerId(), requestDto.getBeneficiaryId());

        FundTransferTransaction transaction = transactionMapper.toEntity(requestDto);
        transaction.setBeneficiaryName(validation.getBeneficiaryName());
        transaction.setStatus(TransactionStatus.INITIATED);
        FundTransferTransaction saved = transactionRepository.save(transaction);
        recordAudit(saved, null, TransactionStatus.INITIATED, "MAKER", "Transaction initiated");

        log.info("Fund transfer transaction {} initiated for customer {}", saved.getTransactionId(), saved.getCustomerId());

        submitForApproval(saved);

        return transactionMapper.toResponseDto(saved);
    }

    @Override
    public TransactionResponseDto getTransactionById(Long transactionId) {
        return transactionMapper.toResponseDto(fetchTransaction(transactionId));
    }

    @Override
    public PageResponse<TransactionResponseDto> getTransactionHistory(Long customerId, Long beneficiaryId,
                                                                        TransactionStatus status, int page, int size,
                                                                        String sortBy, String sortDirection) {
        Sort sort = sortDirection.equalsIgnoreCase("ASC") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<FundTransferTransaction> result = transactionRepository.findAll(
                TransactionSpecification.filterBy(customerId, beneficiaryId, status), pageable);
        return PageResponse.from(result.map(transactionMapper::toResponseDto));
    }

    @Override
    @Transactional
    public TransactionResponseDto modifyAndResubmit(Long transactionId, TransactionRequestDto requestDto) {
        FundTransferTransaction transaction = fetchTransaction(transactionId);

        if (!MODIFIABLE_STATUSES.contains(transaction.getStatus())) {
            throw new BusinessException(String.format(AppConstants.INVALID_STATE_FOR_MODIFICATION,
                    transactionId, transaction.getStatus()));
        }

        BeneficiaryValidationResponseDto validation = validateBeneficiary(transaction.getCustomerId(), requestDto.getBeneficiaryId());

        TransactionStatus previousStatus = transaction.getStatus();
        transactionMapper.updateEntityFromDto(requestDto, transaction);
        transaction.setBeneficiaryName(validation.getBeneficiaryName());
        transaction.setStatus(TransactionStatus.INITIATED);
        FundTransferTransaction updated = transactionRepository.save(transaction);
        recordAudit(updated, previousStatus, TransactionStatus.INITIATED, "MAKER", "Transaction modified and resubmitted");

        log.info("Transaction {} modified and resubmitted for approval", transactionId);
        submitForApproval(updated);

        return transactionMapper.toResponseDto(updated);
    }

    @Override
    @Transactional
    public TransactionResponseDto updateTransactionStatus(Long transactionId, TransactionStatusUpdateDto updateDto) {
        FundTransferTransaction transaction = fetchTransaction(transactionId);
        TransactionStatus previousStatus = transaction.getStatus();

        transaction.setStatus(updateDto.getNewStatus());
        if (updateDto.getApprovalReferenceId() != null) {
            transaction.setApprovalReferenceId(updateDto.getApprovalReferenceId());
        }
        FundTransferTransaction updated = transactionRepository.save(transaction);

        String changedBy = updateDto.getChangedBy() != null ? updateDto.getChangedBy() : AppConstants.SYSTEM_USER;
        recordAudit(updated, previousStatus, updateDto.getNewStatus(), changedBy, updateDto.getRemarks());

        log.info("Transaction {} status changed from {} to {}", transactionId, previousStatus, updateDto.getNewStatus());
        return transactionMapper.toResponseDto(updated);
    }

    @Override
    public List<TransactionAuditResponseDto> getAuditHistory(Long transactionId) {
        fetchTransaction(transactionId);
        return auditRepository.findByTransaction_TransactionIdOrderByChangedDateAsc(transactionId).stream()
                .map(transactionMapper::toAuditResponseDto)
                .collect(Collectors.toList());
    }

    private void submitForApproval(FundTransferTransaction transaction) {
        try {
            ApprovalSubmissionRequestDto submissionRequest = ApprovalSubmissionRequestDto.builder()
                    .transactionId(transaction.getTransactionId())
                    .customerId(transaction.getCustomerId())
                    .submittedBy(transaction.getInitiatedBy())
                    .amount(transaction.getAmount())
                    .currency(transaction.getCurrency())
                    .remarks(transaction.getRemarks())
                    .build();

            ApiResponse<ApprovalSubmissionResponseDto> response = approvalServiceClient.submitForApproval(submissionRequest);

            TransactionStatus previousStatus = transaction.getStatus();
            transaction.setStatus(TransactionStatus.PENDING_APPROVAL);
            if (response.getData() != null) {
                transaction.setApprovalReferenceId(response.getData().getApprovalId());
            }
            transactionRepository.save(transaction);
            recordAudit(transaction, previousStatus, TransactionStatus.PENDING_APPROVAL, AppConstants.SYSTEM_USER,
                    "Submitted to approval workflow");
        } catch (FeignException ex) {
            log.error("Failed to submit transaction {} to Approval Service", transaction.getTransactionId(), ex);
            throw new ServiceUnavailableException("Unable to submit transaction for approval at this time. Please try again later");
        }
    }

    private BeneficiaryValidationResponseDto validateBeneficiary(Long customerId, Long beneficiaryId) {
        try {
            ApiResponse<BeneficiaryValidationResponseDto> response =
                    beneficiaryServiceClient.validateBeneficiary(beneficiaryId, customerId);
            BeneficiaryValidationResponseDto validation = response.getData();

            if (validation == null || !validation.isValid()) {
                String message = validation != null ? validation.getMessage() : "Beneficiary could not be validated";
                throw new BusinessException(String.format(AppConstants.BENEFICIARY_VALIDATION_FAILED, message));
            }
            return validation;
        } catch (FeignException ex) {
            log.error("Failed to validate beneficiary {} for customer {}", beneficiaryId, customerId, ex);
            throw new ServiceUnavailableException(AppConstants.BENEFICIARY_SERVICE_UNAVAILABLE);
        }
    }

    private void recordAudit(FundTransferTransaction transaction, TransactionStatus previousStatus,
                              TransactionStatus newStatus, String changedBy, String remarks) {
        TransactionAudit audit = TransactionAudit.builder()
                .transaction(transaction)
                .previousStatus(previousStatus)
                .newStatus(newStatus)
                .changedBy(changedBy)
                .remarks(remarks)
                .build();
        auditRepository.save(audit);
    }

    private FundTransferTransaction fetchTransaction(Long transactionId) {
        return transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        String.format(AppConstants.TRANSACTION_NOT_FOUND, transactionId)));
    }
}
