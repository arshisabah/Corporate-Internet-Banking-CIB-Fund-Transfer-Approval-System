# CIB Fund Transfer & Approval System

A Corporate Internet Banking (CIB) Fund Transfer & Approval System built as independently deployable
Spring Boot microservices, covering the complete lifecycle of a corporate fund transfer — from creation,
to approval, to execution — with a full audit trail.

## Modules

| Module | Description |
|---|---|
| `eureka-server` | Netflix Eureka service registry |
| `customer-service` | Corporate customer & corporate user master data |
| `beneficiary-service` | Beneficiary CRUD + beneficiary activation validation |
| `fund-transfer-service` | Fund transfer initiation, history, status tracking, audit trail |
| `approval-service` | Approval workflow: approve / reject / return-for-modification, approval history |
| `docs/` | Architecture diagram, ER diagrams / table design, REST API design |

See `docs/architecture.md`, `docs/database-design.md`, and `docs/api-design.md` for the full design.

## Tech Stack

- Java 17, Spring Boot 3.3.x
- Spring Cloud 2023.0.3 (Netflix Eureka Client/Server, OpenFeign)
- Spring Data JPA (H2 for `dev`, PostgreSQL for `qa`/`prod`)
- springdoc-openapi (Swagger UI) per service
- Lombok, Bean Validation (`jakarta.validation`)

## Running Locally (without Docker)

Each module is a standalone Maven project. Requires Java 17 and Maven 3.9+, with access to Maven Central
(this sandbox environment does not have that access, so the build was not executed here — see note below).

```bash
# 1. Start the registry first
cd eureka-server && mvn spring-boot:run

# 2. Start each business service (in separate terminals), each defaults to the 'dev' profile (H2 in-memory)
cd customer-service        && mvn spring-boot:run   # :8081
cd beneficiary-service      && mvn spring-boot:run   # :8082
cd approval-service         && mvn spring-boot:run   # :8084
cd fund-transfer-service    && mvn spring-boot:run   # :8083
```

To point at QA/Prod databases instead of the in-memory H2 default, run with:
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=qa
```
and supply `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` as environment variables — no code changes required.

## Running with Docker Compose

```bash
docker-compose up --build
```

This brings up all five containers (`eureka-server` + four services) networked together, with each
service registering itself in Eureka by service name.

## Swagger / OpenAPI

Once running:
- Customer Service: http://localhost:8081/swagger-ui.html
- Beneficiary Service: http://localhost:8082/swagger-ui.html
- Fund Transfer Service: http://localhost:8083/swagger-ui.html
- Approval Service: http://localhost:8084/swagger-ui.html
- Eureka dashboard: http://localhost:8761

## End-to-End Test Flow

1. `POST /api/v1/customers` (customer-service) → create a corporate customer.
2. `POST /api/v1/customers/{customerId}/users` → create a MAKER user.
3. `POST /api/v1/beneficiaries` (beneficiary-service) → add an ACTIVE beneficiary for that customer.
4. `POST /api/v1/transactions` (fund-transfer-service) → initiate a transfer; it auto-validates the
   beneficiary and auto-submits into the approval workflow (status becomes `PENDING_APPROVAL`).
5. `GET /api/v1/approvals?customerId={customerId}&status=PENDING` (approval-service) → find the pending approval.
6. `POST /api/v1/approvals/{approvalId}/approve` → approve it. Fund Transfer Service transaction status
   flips to `EXECUTED` automatically via the Feign callback.
7. `GET /api/v1/transactions/{transactionId}/audit-history` → view the complete audit trail.

## Note on Build Verification

This code was generated and manually reviewed (package structure, brace/syntax balance) in a sandboxed
environment without access to Maven Central, so `mvn clean install` could not be executed here to produce
a compiled artifact. All classes follow standard Spring Boot 3.3 / Spring Cloud 2023.0.3 APIs; running
`mvn clean install` in an environment with internet access is expected to build cleanly. Please report
any compile issue and it can be quickly patched.
