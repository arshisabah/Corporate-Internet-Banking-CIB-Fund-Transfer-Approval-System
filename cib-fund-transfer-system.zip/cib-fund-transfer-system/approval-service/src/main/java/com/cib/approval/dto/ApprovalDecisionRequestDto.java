package com.cib.approval.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalDecisionRequestDto {

    @NotNull(message = "Approver id is required")
    private Long approverId;

    private String remarks;
}
