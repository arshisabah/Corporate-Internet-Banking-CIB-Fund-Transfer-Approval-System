package com.cib.approval.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalSubmissionRequestDto {

    @NotNull(message = "Transaction id is required")
    private Long transactionId;

    @NotNull(message = "Customer id is required")
    private Long customerId;

    @NotNull(message = "Submitted by (user id) is required")
    private Long submittedBy;

    @NotNull(message = "Amount is required")
    private BigDecimal amount;

    @NotBlank(message = "Currency is required")
    private String currency;

    private String remarks;
}
