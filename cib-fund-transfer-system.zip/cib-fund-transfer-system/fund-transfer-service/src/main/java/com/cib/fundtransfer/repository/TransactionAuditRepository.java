package com.cib.fundtransfer.repository;

import com.cib.fundtransfer.entity.TransactionAudit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransactionAuditRepository extends JpaRepository<TransactionAudit, Long> {

    List<TransactionAudit> findByTransaction_TransactionIdOrderByChangedDateAsc(Long transactionId);
}
