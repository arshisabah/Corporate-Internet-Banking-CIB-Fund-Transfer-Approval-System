package com.cib.fundtransfer.client;

import com.cib.fundtransfer.dto.ApiResponse;
import com.cib.fundtransfer.dto.BeneficiaryValidationResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Feign client used to communicate with the Beneficiary Service via Service Discovery (Eureka)
 * using the logical service name instead of a hardcoded host/port.
 */
@FeignClient(name = "beneficiary-service")
public interface BeneficiaryServiceClient {

    @GetMapping("/api/v1/beneficiaries/{beneficiaryId}/validate")
    ApiResponse<BeneficiaryValidationResponseDto> validateBeneficiary(
            @PathVariable("beneficiaryId") Long beneficiaryId,
            @RequestParam("customerId") Long customerId);
}
