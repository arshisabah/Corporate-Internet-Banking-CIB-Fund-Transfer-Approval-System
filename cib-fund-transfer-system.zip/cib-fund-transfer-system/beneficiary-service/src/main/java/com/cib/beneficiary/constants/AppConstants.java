package com.cib.beneficiary.constants;

public final class AppConstants {

    private AppConstants() {
    }

    public static final String DEFAULT_PAGE_NUMBER = "0";
    public static final String DEFAULT_PAGE_SIZE = "10";
    public static final String DEFAULT_SORT_BY = "createdDate";
    public static final String DEFAULT_SORT_DIRECTION = "DESC";

    public static final String BENEFICIARY_NOT_FOUND = "Beneficiary not found with id: %s";
    public static final String BENEFICIARY_ALREADY_EXISTS =
            "Beneficiary with account number %s already exists for this customer";
    public static final String BENEFICIARY_NOT_ACTIVE =
            "Beneficiary with id %s is not active. Fund transfer cannot be initiated";
}
