package com.cib.customer.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customerServiceOpenAPI() {
        return new OpenAPI().info(new Info()
                .title("Customer Service API")
                .description("APIs for managing corporate customers and corporate users in the CIB platform")
                .version("v1.0.0"));
    }
}
