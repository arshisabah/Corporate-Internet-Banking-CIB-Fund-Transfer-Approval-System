package com.cib.beneficiary.mapper;

import com.cib.beneficiary.dto.BeneficiaryRequestDto;
import com.cib.beneficiary.dto.BeneficiaryResponseDto;
import com.cib.beneficiary.entity.Beneficiary;
import org.springframework.stereotype.Component;

@Component
public class BeneficiaryMapper {

    public Beneficiary toEntity(BeneficiaryRequestDto dto) {
        return Beneficiary.builder()
                .customerId(dto.getCustomerId())
                .beneficiaryName(dto.getBeneficiaryName())
                .nickname(dto.getNickname())
                .accountNumber(dto.getAccountNumber())
                .ifscCode(dto.getIfscCode())
                .bankName(dto.getBankName())
                .email(dto.getEmail())
                .status(dto.getStatus())
                .build();
    }

    public BeneficiaryResponseDto toResponseDto(Beneficiary entity) {
        return BeneficiaryResponseDto.builder()
                .beneficiaryId(entity.getBeneficiaryId())
                .customerId(entity.getCustomerId())
                .beneficiaryName(entity.getBeneficiaryName())
                .nickname(entity.getNickname())
                .accountNumber(entity.getAccountNumber())
                .ifscCode(entity.getIfscCode())
                .bankName(entity.getBankName())
                .email(entity.getEmail())
                .status(entity.getStatus())
                .createdDate(entity.getCreatedDate())
                .updatedDate(entity.getUpdatedDate())
                .build();
    }

    public void updateEntityFromDto(BeneficiaryRequestDto dto, Beneficiary entity) {
        entity.setBeneficiaryName(dto.getBeneficiaryName());
        entity.setNickname(dto.getNickname());
        entity.setAccountNumber(dto.getAccountNumber());
        entity.setIfscCode(dto.getIfscCode());
        entity.setBankName(dto.getBankName());
        entity.setEmail(dto.getEmail());
        if (dto.getStatus() != null) {
            entity.setStatus(dto.getStatus());
        }
    }
}
